package project3150;

import java.util.ArrayList;


public class CentralComputer{
	
	
	protected static int limit;
	
	protected static int count;
	
	protected static boolean adjustCount;
	
	private ArrayList<Person> Store;
	
	public CentralComputer() {
		
		this.Store = new ArrayList<>();
		
		this.limit = 0;
		
		int count = 0;
		
	}
	
	
	protected int adjustCount() {
		
		return 0;
	}
	
	
	protected void enter(Person p) {
		
		if(BarrierSystem.activated == false) {
			this.Store.add(p);
		
		if(adjustCount) {
			
			count++;
			adjustCount = false;
		}
	}
}
	
	protected void exit(int index) {
		
		this.Store.remove(index);
		
		if(adjustCount && count > 0) {
			count--;
		}
	}
	
	
	protected int getSize() {
		
		
		return this.Store.size();
	}
	
	
	
	protected void clearStore() {
		
		this.Store.clear();
	}
	
	
}