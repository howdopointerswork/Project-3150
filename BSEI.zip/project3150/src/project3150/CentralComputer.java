package project3150;

import java.util.ArrayList;


public class CentralComputer{
	
	
	protected int limit;
	
	private ArrayList<Person> Store;
	
	public CentralComputer() {
		
		this.Store = new ArrayList<>();
		
		this.limit = 0;
		
	}
	
	
	protected int adjustCount() {
		
		return 0;
	}
	
	
	protected void addCustomer(Person p) {
		
		this.Store.add(p);
	}
	
	protected void removeCustomer(int index) {
		
		this.Store.remove(index);
	}
	
	protected int getSize() {
		
		
		return this.Store.size();
	}
	
	
	
	protected void clearStore() {
		
		this.Store.clear();
	}
	
	
}