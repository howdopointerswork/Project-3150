package project3150;


public class CountingSystem{
	
	private int address;
	
	public CountingSystem(){
		
		this.address = 0;
		
	}
	
	public int detectEnter() {
		
		return 0;
		
	}
	
	public int detectExit() {
		
		
		return 0;
	}
	
	
	public void setAddress(int newAddress) {
		
		this.address = newAddress;
		
	}
	
	public int getAddress() {
		
		return this.address;
	}
	
	
	
	
	
	
	
	
	
}