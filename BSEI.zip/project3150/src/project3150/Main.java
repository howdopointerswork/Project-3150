package project3150;

import java.util.ArrayList;

public class Main{
	
	public static void main(String[] args) {
		
		CentralComputer comp = new CentralComputer();
		
		ArrayList<Customer> customers = new ArrayList<>();
		
		ArrayList<Manager> managers = new ArrayList<>();
		
		ArrayList<Employee> employees = new ArrayList<>();
		
		
		
		
	}
	
	
}