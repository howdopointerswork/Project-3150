package project3150;


public class Customer extends Person{
	
	public Customer(String name) {
		
		super(name);
		
	}
	
	
	
	
	
	
}