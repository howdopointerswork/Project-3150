package project3150;


public class Customer extends Person{
	
	public Customer(String name) {
		
		super(name);
		
	}
	
	@Override
	public void enter() {
		
		
	}
	
	
	@Override
	public void exit() {
		
		
	}
	
	
}