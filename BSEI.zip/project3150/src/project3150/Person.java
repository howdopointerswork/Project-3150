package project3150;


abstract class Person{
	
	private String name;
	
	
	public Person(String name) {
		
		this.name = name;
		
	}
	
	
	abstract void enter();
	
	abstract void exit();
	
	
	
	private String getName() {
		
		return this.name;
	}
	
	
	
	
}