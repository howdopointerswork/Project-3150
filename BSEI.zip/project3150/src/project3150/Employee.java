package project3150;


public class Employee extends Person{
	
	//keycard
	
	public Employee(String name) {
		
		super(name);
	}
	
	@Override
	public void enter() {
		
		
	}
	
	
	@Override 
	public void exit() {
		
		
	}
	
	
	
	
}