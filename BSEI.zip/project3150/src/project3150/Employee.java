package project3150;


public class Employee extends Personnel{
	
	//keycard
	public Employee(String name) {
		
		super(name);
		
		
	}
	

		
	}

	
	
	
	
