package project3150;

public class Personnel extends Person{
	
	final boolean keyCard = true;
	
	public Personnel(String name) {
		
		super(name);
	}
	
	
}