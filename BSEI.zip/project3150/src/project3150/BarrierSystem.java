package project3150;


public class BarrierSystem{
	
	protected static boolean activated;
	
	private void checkLimit() {
		if(CentralComputer.count > 0 && CentralComputer.count <= CentralComputer.limit) {
		
			this.activated = false;
		}
		else {
		
			this.activated = true;
		}
	}
	
	protected void useKeyCard(boolean keyCard) {
		
		this.activated = keyCard;
	}
	
	
}