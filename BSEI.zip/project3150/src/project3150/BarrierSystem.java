package project3150;


public class BarrierSystem{
	
	private boolean activated;
	
	
	
	
}