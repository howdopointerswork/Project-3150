package project3150;


public class Manager extends Personnel{
	
	
	
	
	public Manager(String name) {
		
		super(name);
	
		
	}
	
	
	public void setName(String name) {
		
		this.name = name;
	}

	
	
	public int getLimit() {
		
		
		return 0;
	}
	
	
	public int getCurrentCount() {
		
		
		return 0;
	}
	
	
	public void changeLimit() {
		
		
		
	}
	
	
	
	
	
	
}