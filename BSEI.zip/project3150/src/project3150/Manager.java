package project3150;


public class Manager extends Person{
	
	private boolean keycard;
	
	
	public Manager(String name) {
		
		super(name);
		
		this.keycard = true;
		
	}
	
	
	@Override
	public void enter() {
		
		
	}
	
	
	@Override
	public void exit() {
		
		
	}
	
	
	public int getLimit() {
		
		
		return 0;
	}
	
	
	public int getCurrentCount() {
		
		
		return 0;
	}
	
	
	public void changeLimit() {
		
		
		
	}
	
	
	
	
	
	
}